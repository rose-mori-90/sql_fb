UPDATE characters SET species = "Martian" WHERE id = 8;
